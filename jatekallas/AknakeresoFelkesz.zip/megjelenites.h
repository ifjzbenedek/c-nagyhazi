#ifndef MEGJELENITES_H_INCLUDED
#define MEGJELENITES_H_INCLUDED

Kirajzol(Palya palya);

void LepestBeker(int* plepesSorSzam, int* plepesOszlopSzam, char* lepesTipus);

void LepesTipusokatKiir();

#endif // MEGJELENITES_H_INCLUDED
